﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace ScooterRentalClassLibrary
{
    [TestFixture]
    public class ScooterRentalTests
    {

        decimal pricePerMinute = 0.10M;
        private ScooterService CreateScooterService() {

            return new ScooterService();
        }
        

        [Test]
        public void Test_Update_Available_Scooters_List()
        {

            var scooterService = CreateScooterService();
            var initailAmmountOfSccoters = scooterService.GetScooters();
            scooterService.AddScooter("1", pricePerMinute);
            var result = scooterService.GetScooters();
            Assert.Greater(result.Count, initailAmmountOfSccoters.Count);
        }

        public void Test_Rent_Scooter() { }
        public void Test_Calculate_Rental_Price_When_Rental_Ends() {
        }

    }
}
