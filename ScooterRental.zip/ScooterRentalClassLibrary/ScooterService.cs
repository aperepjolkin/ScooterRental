﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScooterRentalClassLibrary
{
    public class ScooterService : IScooterService
    {
        private List<Scooter> _scooterList;
        public ScooterService() {
            _scooterList = new List<Scooter>();
        }

        public void AddScooter(string id, decimal pricePerMinute)
        {
            var s = new Scooter(id, pricePerMinute);

            _scooterList.Add(s);
        }

        public Scooter GetScooterById(string scooterId)
        {
            return _scooterList.Find(scooter => scooter.Id == scooterId);
        }

        public IList<Scooter> GetScooters()
        {
            return _scooterList;
        }

        public void RemoveScooter(string id)
        {
            var scooterToRemove = _scooterList.SingleOrDefault(scooter => scooter.Id == id);
            if (scooterToRemove != null)
                _scooterList.Remove(scooterToRemove);
        }
    }
}
